/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        base: "#0D1117",
        surface: "#161B22",
        raised: "#1C2230",
        line: "#272E3B",
        ink: "#E7E2D6",
        muted: "#8B93A1",
        amber: {
          DEFAULT: "#E8A33D",
          soft: "#F0BD6D",
          dim: "#8A6326",
        },
        steel: {
          DEFAULT: "#6EA8D9",
          soft: "#9BC4E6",
        },
        good: "#7FB88F",
        bad: "#D9707A",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      backgroundImage: {
        grid: "linear-gradient(#272E3B 1px, transparent 1px), linear-gradient(90deg, #272E3B 1px, transparent 1px)",
      },
      backgroundSize: {
        grid: "32px 32px",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(232,163,61,0.15), 0 8px 30px -8px rgba(232,163,61,0.25)",
      },
    },
  },
  plugins: [],
};
