Drop your resume PDF here as "resume.pdf" so the download button on the
/resume page works (frontend/src/pages/public/Resume.jsx links to /resume.pdf).
