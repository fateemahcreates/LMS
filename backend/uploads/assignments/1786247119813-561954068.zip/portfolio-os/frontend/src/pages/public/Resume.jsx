import { useEffect, useState } from "react";
import api from "../../services/api.js";
import SectionHeading from "../../components/SectionHeading.jsx";
import Loader from "../../components/Loader.jsx";
import { FiDownload } from "react-icons/fi";

const Resume = () => {
  const [experience, setExperience] = useState([]);
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get("/experience"), api.get("/skills")])
      .then(([e, s]) => {
        setExperience(e.data.data);
        setSkills(s.data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader label="loading resume" />;

  return (
    <div className="container-shell py-20 max-w-3xl">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <SectionHeading eyebrow="resume" title="Experience at a glance" />
        <a href="/resume.pdf" download className="btn-primary h-fit">
          <FiDownload /> Download PDF
        </a>
      </div>

      <div className="space-y-10">
        {experience.map((e) => (
          <div key={e._id} className="panel p-6">
            <div className="flex justify-between flex-wrap gap-2">
              <h3 className="font-display text-xl font-semibold">{e.position}</h3>
              <span className="font-mono text-xs text-muted">
                {new Date(e.startDate).getFullYear()} — {e.current ? "present" : new Date(e.endDate).getFullYear()}
              </span>
            </div>
            <p className="text-muted mt-1">{e.company}</p>
            <p className="mt-3 text-ink">{e.description}</p>
          </div>
        ))}
      </div>

      <div className="mt-14">
        <p className="eyebrow mb-4">skills summary</p>
        <div className="flex flex-wrap gap-2">
          {skills.map((s) => <span key={s._id} className="tag">{s.name}</span>)}
        </div>
      </div>
    </div>
  );
};

export default Resume;
