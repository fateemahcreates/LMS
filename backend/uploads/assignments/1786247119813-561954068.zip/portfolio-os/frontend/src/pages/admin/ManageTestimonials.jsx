import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ImageUpload from "../../components/ImageUpload.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX, FiStar } from "react-icons/fi";

const emptyForm = { name: "", company: "", position: "", photo: "", rating: 5, review: "", approved: true };

const ManageTestimonials = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const load = () => {
    setLoading(true);
    api.get("/testimonials").then((res) => setItems(res.data.data)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (t) => { setForm(t); setEditing(t); };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing?._id) await api.put(`/testimonials/${editing._id}`, form);
    else await api.post("/testimonials", form);
    close();
    load();
  };

  const handleDelete = async (id) => { await api.delete(`/testimonials/${id}`); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">testimonials</p>
          <h1 className="font-display text-3xl font-semibold">Manage testimonials</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New testimonial</button>
      </div>

      {loading ? <Loader label="loading testimonials" /> : (
        <div className="panel divide-y divide-line">
          {items.map((t) => (
            <div key={t._id} className="flex items-center justify-between p-4 gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium truncate">{t.name}</p>
                  <span className="flex items-center gap-0.5 text-amber text-xs">
                    <FiStar className="fill-amber" /> {t.rating}
                  </span>
                  {!t.approved && <span className="tag">hidden</span>}
                </div>
                <p className="text-muted text-sm truncate">{t.review}</p>
              </div>
              <div className="flex items-center gap-4 shrink-0">
                <button onClick={() => openEdit(t)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(t._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-xl my-8 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit testimonial" : "New testimonial"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Position</label>
                <input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Company</label>
              <input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <ImageUpload value={form.photo} onChange={(url) => setForm({ ...form, photo: url })} label="Photo" />
            <div>
              <label className="text-xs font-mono text-muted">Review</label>
              <textarea required rows={3} value={form.review} onChange={(e) => setForm({ ...form, review: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div className="flex items-center gap-6">
              <div>
                <label className="text-xs font-mono text-muted">Rating</label>
                <select value={form.rating} onChange={(e) => setForm({ ...form, rating: +e.target.value })}
                  className="block bg-raised border border-line rounded-md px-3 py-2 mt-1 text-sm">
                  {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} stars</option>)}
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm mt-5">
                <input type="checkbox" checked={form.approved} onChange={(e) => setForm({ ...form, approved: e.target.checked })} />
                Visible on site
              </label>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" className="btn-primary">Save testimonial</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageTestimonials;
