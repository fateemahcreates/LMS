import { useEffect, useState } from "react";
import api from "../../services/api.js";
import ProjectCard from "../../components/ProjectCard.jsx";
import SkeletonCard from "../../components/SkeletonCard.jsx";
import SectionHeading from "../../components/SectionHeading.jsx";
import { FiSearch } from "react-icons/fi";

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");

  useEffect(() => {
    setLoading(true);
    const params = {};
    if (search) params.search = search;
    if (category !== "all") params.category = category;
    const timeout = setTimeout(() => {
      api.get("/projects", { params }).then((res) => setProjects(res.data.data)).finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(timeout);
  }, [search, category]);

  const categories = ["all", ...new Set(projects.map((p) => p.category))];

  return (
    <div className="container-shell py-20">
      <SectionHeading
        eyebrow="portfolio"
        title="Projects"
        description="Case studies covering the problem, the architecture, and what shipped."
      />

      <div className="flex flex-col sm:flex-row gap-4 mb-10">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input
            type="text"
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-surface border border-line rounded-md pl-10 pr-4 py-2.5 text-sm focus:border-amber outline-none"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="bg-surface border border-line rounded-md px-4 py-2.5 text-sm font-mono focus:border-amber outline-none"
        >
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
          : projects.length > 0
          ? projects.map((p) => <ProjectCard key={p._id} project={p} />)
          : (
            <div className="col-span-full text-center py-16 font-mono text-muted">
              no projects match that search — try clearing the filters
            </div>
          )}
      </div>
    </div>
  );
};

export default Projects;
