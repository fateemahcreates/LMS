import { useEffect, useState } from "react";
import api from "../../services/api.js";
import SectionHeading from "../../components/SectionHeading.jsx";
import Loader from "../../components/Loader.jsx";

const About = () => {
  const [experience, setExperience] = useState([]);
  const [skills, setSkills] = useState([]);
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get("/experience"), api.get("/skills"), api.get("/certificates")])
      .then(([e, s, c]) => {
        setExperience(e.data.data);
        setSkills(s.data.data);
        setCertificates(c.data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader label="loading profile" />;

  const grouped = skills.reduce((acc, s) => {
    acc[s.category] = acc[s.category] || [];
    acc[s.category].push(s);
    return acc;
  }, {});

  return (
    <div className="container-shell py-20">
      <p className="eyebrow mb-4">about</p>
      <h1 className="font-display text-4xl md:text-5xl font-semibold max-w-2xl">
        Full-stack developer, focused on shipping complete systems.
      </h1>
      <p className="text-muted mt-6 max-w-2xl leading-relaxed">
        I design and build full-stack applications end to end — from data models and
        API design through to the interfaces people actually use. Recent work spans
        content platforms, health dashboards, and the admin tooling that keeps them running.
      </p>

      {/* Career journey */}
      <div className="mt-16">
        <SectionHeading eyebrow="career journey" title="Experience" />
        <div className="relative pl-8 border-l border-line space-y-10">
          {experience.map((e) => (
            <div key={e._id} className="relative">
              <span className="absolute -left-[2.35rem] top-1.5 w-3 h-3 rounded-full bg-amber" />
              <p className="font-mono text-xs text-muted">
                {new Date(e.startDate).getFullYear()} — {e.current ? "present" : new Date(e.endDate).getFullYear()}
              </p>
              <h3 className="font-display text-xl font-semibold mt-1">{e.position} · {e.company}</h3>
              <p className="text-muted mt-2 max-w-xl">{e.description}</p>
              {e.technologies?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {e.technologies.map((t) => <span key={t} className="tag">{t}</span>)}
                </div>
              )}
              {e.achievements?.length > 0 && (
                <ul className="mt-3 space-y-1 text-sm text-ink">
                  {e.achievements.map((a, i) => (
                    <li key={i} className="flex gap-2"><span className="text-amber">›</span> {a}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Skills by category */}
      <div className="mt-20">
        <SectionHeading eyebrow="tech stack" title="Skills" />
        <div className="grid md:grid-cols-2 gap-8">
          {Object.entries(grouped).map(([category, list]) => (
            <div key={category}>
              <p className="font-mono text-xs uppercase text-muted mb-3">{category}</p>
              <div className="space-y-3">
                {list.map((s) => (
                  <div key={s._id}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{s.name}</span>
                      <span className="text-muted font-mono text-xs">{s.yearsExperience}y</span>
                    </div>
                    <div className="h-1.5 bg-raised rounded-full overflow-hidden">
                      <div className="h-full bg-steel rounded-full" style={{ width: `${s.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Certifications */}
      {certificates.length > 0 && (
        <div className="mt-20">
          <SectionHeading eyebrow="credentials" title="Certifications" />
          <div className="grid md:grid-cols-3 gap-6">
            {certificates.map((c) => (
              <div key={c._id} className="panel p-5">
                <h3 className="font-display font-semibold">{c.title}</h3>
                <p className="text-muted text-sm mt-1">{c.organization}</p>
                <p className="font-mono text-xs text-muted mt-3">
                  issued {new Date(c.issueDate).toLocaleDateString()}
                </p>
                {c.credentialURL && (
                  <a href={c.credentialURL} target="_blank" rel="noreferrer" className="text-amber text-sm mt-2 inline-block">
                    verify credential →
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default About;
