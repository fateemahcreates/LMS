import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ImageUpload from "../../components/ImageUpload.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX } from "react-icons/fi";

const emptyForm = { title: "", organization: "", image: "", credentialURL: "", issueDate: "", expiryDate: "" };
const toDateInput = (d) => (d ? new Date(d).toISOString().slice(0, 10) : "");

const ManageCertificates = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const load = () => {
    setLoading(true);
    api.get("/certificates").then((res) => setItems(res.data.data)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (c) => { setForm({ ...c, issueDate: toDateInput(c.issueDate), expiryDate: toDateInput(c.expiryDate) }); setEditing(c); };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing?._id) await api.put(`/certificates/${editing._id}`, form);
    else await api.post("/certificates", form);
    close();
    load();
  };

  const handleDelete = async (id) => { await api.delete(`/certificates/${id}`); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">certificates</p>
          <h1 className="font-display text-3xl font-semibold">Manage certificates</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New certificate</button>
      </div>

      {loading ? <Loader label="loading certificates" /> : (
        <div className="panel divide-y divide-line">
          {items.map((c) => (
            <div key={c._id} className="flex items-center justify-between p-4 gap-4">
              <div>
                <p className="font-medium">{c.title}</p>
                <p className="text-muted text-sm">{c.organization} · issued {new Date(c.issueDate).getFullYear()}</p>
              </div>
              <div className="flex items-center gap-4">
                <button onClick={() => openEdit(c)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(c._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-xl my-8 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit certificate" : "New certificate"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Title</label>
              <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Issuing organization</label>
              <input required value={form.organization} onChange={(e) => setForm({ ...form, organization: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <ImageUpload value={form.image} onChange={(url) => setForm({ ...form, image: url })} label="Badge / image" />
            <div>
              <label className="text-xs font-mono text-muted">Credential URL</label>
              <input value={form.credentialURL} onChange={(e) => setForm({ ...form, credentialURL: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Issue date</label>
                <input type="date" required value={form.issueDate} onChange={(e) => setForm({ ...form, issueDate: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Expiry date</label>
                <input type="date" value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" className="btn-primary">Save certificate</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageCertificates;
