import { useState } from "react";
import { useForm } from "react-hook-form";
import api from "../../services/api.js";
import SectionHeading from "../../components/SectionHeading.jsx";
import { FiMail, FiMapPin, FiCheckCircle } from "react-icons/fi";

const Contact = () => {
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm();
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const onSubmit = async (data) => {
    setError("");
    try {
      await api.post("/messages", data);
      setSent(true);
      reset();
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong. Try again in a moment.");
    }
  };

  return (
    <div className="container-shell py-20">
      <SectionHeading eyebrow="get in touch" title="Contact" description="Open to full-time roles, contract work, and interesting problems." />

      <div className="grid md:grid-cols-3 gap-10">
        <div className="space-y-6 font-mono text-sm">
          <div className="flex items-start gap-3">
            <FiMail className="text-amber mt-1" />
            <div>
              <p className="text-muted text-xs uppercase">email</p>
              <p>hello@example.com</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <FiMapPin className="text-amber mt-1" />
            <div>
              <p className="text-muted text-xs uppercase">based in</p>
              <p>Remote / Open to relocation</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="md:col-span-2 panel p-6 space-y-4">
          {sent ? (
            <div className="flex flex-col items-center text-center py-10 gap-3">
              <FiCheckCircle className="text-good text-4xl" />
              <p className="font-display text-xl font-semibold">Message sent</p>
              <p className="text-muted text-sm">Thanks for reaching out — I'll reply as soon as I can.</p>
              <button onClick={() => setSent(false)} className="btn-ghost mt-2">Send another</button>
            </div>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono text-muted">Name</label>
                  <input
                    {...register("name", { required: "Name is required" })}
                    className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none"
                  />
                  {errors.name && <p className="text-bad text-xs mt-1">{errors.name.message}</p>}
                </div>
                <div>
                  <label className="text-xs font-mono text-muted">Email</label>
                  <input
                    type="email"
                    {...register("email", { required: "Email is required" })}
                    className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none"
                  />
                  {errors.email && <p className="text-bad text-xs mt-1">{errors.email.message}</p>}
                </div>
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Subject</label>
                <input
                  {...register("subject")}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Message</label>
                <textarea
                  rows={5}
                  {...register("message", { required: "Message can't be empty" })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none"
                />
                {errors.message && <p className="text-bad text-xs mt-1">{errors.message.message}</p>}
              </div>
              {error && <p className="text-bad text-sm">{error}</p>}
              <button type="submit" disabled={isSubmitting} className="btn-primary w-full sm:w-auto disabled:opacity-60">
                {isSubmitting ? "Sending..." : "Send message"}
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
};

export default Contact;
