import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX } from "react-icons/fi";

const emptyForm = {
  company: "", position: "", startDate: "", endDate: "", current: false,
  description: "", technologies: "", achievements: "",
};

const toDateInput = (d) => (d ? new Date(d).toISOString().slice(0, 10) : "");

const ManageExperience = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const load = () => {
    setLoading(true);
    api.get("/experience").then((res) => setItems(res.data.data)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (e) => {
    setForm({
      ...e,
      startDate: toDateInput(e.startDate),
      endDate: toDateInput(e.endDate),
      technologies: (e.technologies || []).join(", "),
      achievements: (e.achievements || []).join("\n"),
    });
    setEditing(e);
  };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      technologies: form.technologies.split(",").map((t) => t.trim()).filter(Boolean),
      achievements: form.achievements.split("\n").map((a) => a.trim()).filter(Boolean),
      endDate: form.current ? undefined : form.endDate || undefined,
    };
    if (editing?._id) await api.put(`/experience/${editing._id}`, payload);
    else await api.post("/experience", payload);
    close();
    load();
  };

  const handleDelete = async (id) => { await api.delete(`/experience/${id}`); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">experience</p>
          <h1 className="font-display text-3xl font-semibold">Manage experience</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New entry</button>
      </div>

      {loading ? <Loader label="loading experience" /> : (
        <div className="panel divide-y divide-line">
          {items.map((e) => (
            <div key={e._id} className="flex items-center justify-between p-4 gap-4">
              <div>
                <p className="font-medium">{e.position} · {e.company}</p>
                <p className="text-muted text-sm">
                  {new Date(e.startDate).getFullYear()} — {e.current ? "present" : e.endDate ? new Date(e.endDate).getFullYear() : ""}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <button onClick={() => openEdit(e)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(e._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-xl my-8 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit entry" : "New entry"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Company</label>
                <input required value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Position</label>
                <input required value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Start date</label>
                <input type="date" required value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">End date</label>
                <input type="date" disabled={form.current} value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none disabled:opacity-40" />
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.current} onChange={(e) => setForm({ ...form, current: e.target.checked })} />
              Current role
            </label>
            <div>
              <label className="text-xs font-mono text-muted">Description</label>
              <textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Technologies (comma separated)</label>
              <input value={form.technologies} onChange={(e) => setForm({ ...form, technologies: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Achievements (one per line)</label>
              <textarea rows={3} value={form.achievements} onChange={(e) => setForm({ ...form, achievements: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" className="btn-primary">Save entry</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageExperience;
