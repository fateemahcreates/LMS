import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="container-shell py-32 text-center">
    <p className="font-mono text-amber text-sm mb-4">error 404</p>
    <h1 className="font-display text-4xl font-semibold">Route not found</h1>
    <p className="text-muted mt-3">The page you're looking for doesn't exist, or moved.</p>
    <Link to="/" className="btn-primary mt-8 inline-flex">Back to home</Link>
  </div>
);

export default NotFound;
