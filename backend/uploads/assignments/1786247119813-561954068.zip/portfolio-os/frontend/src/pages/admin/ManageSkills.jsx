import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX } from "react-icons/fi";

const emptyForm = { name: "", category: "Frontend", level: 50, yearsExperience: 1, order: 0 };

const ManageSkills = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);

  const load = () => {
    setLoading(true);
    api.get("/skills").then((res) => setSkills(res.data.data)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (s) => { setForm(s); setEditing(s); };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing?._id) await api.put(`/skills/${editing._id}`, form);
    else await api.post("/skills", form);
    close();
    load();
  };

  const handleDelete = async (id) => { await api.delete(`/skills/${id}`); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">skills</p>
          <h1 className="font-display text-3xl font-semibold">Manage skills</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New skill</button>
      </div>

      {loading ? <Loader label="loading skills" /> : (
        <div className="panel divide-y divide-line">
          {skills.map((s) => (
            <div key={s._id} className="flex items-center justify-between p-4 gap-4">
              <div>
                <p className="font-medium">{s.name}</p>
                <p className="text-muted text-sm">{s.category} · {s.level}% · {s.yearsExperience}y</p>
              </div>
              <div className="flex items-center gap-4">
                <button onClick={() => openEdit(s)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(s._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-center justify-center z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-md space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit skill" : "New skill"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Name</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div>
              <label className="text-xs font-mono text-muted">Category</label>
              <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Level (0-100)</label>
                <input type="number" min="0" max="100" value={form.level} onChange={(e) => setForm({ ...form, level: +e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Years experience</label>
                <input type="number" min="0" value={form.yearsExperience} onChange={(e) => setForm({ ...form, yearsExperience: +e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" className="btn-primary">Save skill</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageSkills;
