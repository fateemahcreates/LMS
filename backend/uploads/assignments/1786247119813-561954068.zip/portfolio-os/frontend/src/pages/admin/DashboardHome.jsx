import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";

const StatCard = ({ label, value }) => (
  <div className="panel p-5">
    <p className="font-mono text-xs uppercase text-muted">{label}</p>
    <p className="font-display text-3xl font-semibold mt-2">{value}</p>
  </div>
);

const DashboardHome = () => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get("/dashboard/stats").then((res) => setStats(res.data.data));
  }, []);

  if (!stats) return <Loader label="loading overview" />;

  return (
    <div>
      <p className="eyebrow mb-2">overview</p>
      <h1 className="font-display text-3xl font-semibold mb-8">Dashboard</h1>

      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <StatCard label="Published projects" value={`${stats.publishedProjects}/${stats.totalProjects}`} />
        <StatCard label="Published posts" value={`${stats.publishedBlogs}/${stats.totalBlogs}`} />
        <StatCard label="Unread messages" value={stats.unreadMessages} />
        <StatCard label="Testimonials" value={stats.totalTestimonials} />
        <StatCard label="Project views" value={stats.totalProjectViews} />
        <StatCard label="Blog views" value={stats.totalBlogViews} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="panel p-5">
          <p className="font-mono text-xs uppercase text-muted mb-4">top projects by views</p>
          <div className="space-y-3">
            {stats.topProjects.map((p) => (
              <div key={p._id} className="flex justify-between text-sm border-b border-line pb-2 last:border-0">
                <span>{p.title}</span>
                <span className="font-mono text-muted">{p.views} views</span>
              </div>
            ))}
          </div>
        </div>

        <div className="panel p-5">
          <div className="flex justify-between items-center mb-4">
            <p className="font-mono text-xs uppercase text-muted">recent messages</p>
            <Link to="/admin/messages" className="text-amber text-xs font-mono">view all</Link>
          </div>
          <div className="space-y-3">
            {stats.recentMessages.length === 0 && <p className="text-muted text-sm">No messages yet.</p>}
            {stats.recentMessages.map((m) => (
              <div key={m._id} className="text-sm border-b border-line pb-2 last:border-0">
                <div className="flex justify-between">
                  <span className="font-medium">{m.name}</span>
                  <span className="font-mono text-xs text-muted">{new Date(m.createdAt).toLocaleDateString()}</span>
                </div>
                <p className="text-muted line-clamp-1">{m.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
