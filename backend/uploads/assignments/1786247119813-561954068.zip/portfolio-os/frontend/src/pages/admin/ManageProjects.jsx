import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ImageUpload from "../../components/ImageUpload.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX } from "react-icons/fi";

const emptyForm = {
  title: "", description: "", problem: "", architecture: "", implementation: "", outcomes: "",
  coverImage: "", github: "", liveDemo: "", techStack: "", category: "Full Stack",
  featured: false, status: "draft",
};

const ManageProjects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // null = closed, {} = new, {...} = edit
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    api.get("/projects", { params: { admin: true } }).then((res) => setProjects(res.data.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (p) => {
    setForm({ ...p, techStack: (p.techStack || []).join(", ") });
    setEditing(p);
  };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = { ...form, techStack: form.techStack.split(",").map((t) => t.trim()).filter(Boolean) };
    try {
      if (editing?._id) {
        await api.put(`/projects/${editing._id}`, payload);
      } else {
        await api.post("/projects", payload);
      }
      close();
      load();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    await api.delete(`/projects/${id}`);
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">projects</p>
          <h1 className="font-display text-3xl font-semibold">Manage projects</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New project</button>
      </div>

      {loading ? (
        <Loader label="loading projects" />
      ) : (
        <div className="panel divide-y divide-line">
          {projects.length === 0 && <p className="p-6 text-muted font-mono text-sm">No projects yet.</p>}
          {projects.map((p) => (
            <div key={p._id} className="flex items-center justify-between p-4 gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium truncate">{p.title}</p>
                  <span className={`tag ${p.status === "published" ? "text-good border-good/40" : ""}`}>{p.status}</span>
                  {p.featured && <span className="tag text-amber border-amber/40">featured</span>}
                </div>
                <p className="text-muted text-sm truncate">{p.category} · {p.views} views · {p.likes} likes</p>
              </div>
              <div className="flex items-center gap-4 shrink-0">
                <button onClick={() => openEdit(p)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(p._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-2xl my-8 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit project" : "New project"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>

            <div>
              <label className="text-xs font-mono text-muted">Title</label>
              <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>

            <div>
              <label className="text-xs font-mono text-muted">Short description</label>
              <textarea required rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {["problem", "architecture", "implementation", "outcomes"].map((f) => (
                <div key={f}>
                  <label className="text-xs font-mono text-muted capitalize">{f}</label>
                  <textarea rows={2} value={form[f]} onChange={(e) => setForm({ ...form, [f]: e.target.value })}
                    className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
                </div>
              ))}
            </div>

            <ImageUpload value={form.coverImage} onChange={(url) => setForm({ ...form, coverImage: url })} label="Cover image" />

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">GitHub URL</label>
                <input value={form.github} onChange={(e) => setForm({ ...form, github: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Live demo URL</label>
                <input value={form.liveDemo} onChange={(e) => setForm({ ...form, liveDemo: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Tech stack (comma separated)</label>
                <input value={form.techStack} onChange={(e) => setForm({ ...form, techStack: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Category</label>
                <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>

            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} />
                Featured
              </label>
              <label className="flex items-center gap-2 text-sm">
                Status
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}
                  className="bg-raised border border-line rounded-md px-2 py-1 text-sm">
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </label>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
                {saving ? "Saving..." : "Save project"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageProjects;
