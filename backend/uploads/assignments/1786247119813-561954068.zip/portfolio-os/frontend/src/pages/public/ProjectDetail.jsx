import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import { FiGithub, FiExternalLink, FiHeart, FiEye, FiArrowLeft } from "react-icons/fi";

const blocks = [
  { key: "problem", label: "the problem" },
  { key: "architecture", label: "architecture" },
  { key: "implementation", label: "implementation" },
  { key: "outcomes", label: "outcomes" },
];

const ProjectDetail = () => {
  const { slug } = useParams();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.get(`/projects/${slug}`).then((res) => setProject(res.data.data)).finally(() => setLoading(false));
  }, [slug]);

  const handleLike = async () => {
    if (liked) return;
    const res = await api.post(`/projects/${slug}/like`);
    setProject(res.data.data);
    setLiked(true);
  };

  if (loading) return <Loader label="loading project" />;
  if (!project) {
    return (
      <div className="container-shell py-24 text-center font-mono text-muted">
        project not found
      </div>
    );
  }

  return (
    <article className="container-shell py-16 max-w-3xl">
      <Link to="/projects" className="font-mono text-sm text-muted hover:text-amber inline-flex items-center gap-2 mb-8">
        <FiArrowLeft /> all projects
      </Link>

      <p className="eyebrow mb-3">{project.category}</p>
      <h1 className="font-display text-4xl font-semibold">{project.title}</h1>
      <p className="text-muted mt-4 text-lg leading-relaxed">{project.description}</p>

      <div className="flex flex-wrap gap-2 mt-6">
        {project.techStack?.map((t) => <span key={t} className="tag">{t}</span>)}
      </div>

      <div className="flex flex-wrap items-center gap-4 mt-6 font-mono text-sm">
        {project.github && (
          <a href={project.github} target="_blank" rel="noreferrer" className="btn-ghost">
            <FiGithub /> source
          </a>
        )}
        {project.liveDemo && (
          <a href={project.liveDemo} target="_blank" rel="noreferrer" className="btn-primary">
            <FiExternalLink /> live demo
          </a>
        )}
        <button onClick={handleLike} className="flex items-center gap-2 text-muted hover:text-amber transition-colors ml-auto">
          <FiHeart className={liked ? "fill-amber text-amber" : ""} /> {project.likes}
        </button>
        <span className="flex items-center gap-2 text-muted"><FiEye /> {project.views}</span>
      </div>

      {project.coverImage && (
        <img src={project.coverImage} alt={project.title} className="w-full rounded-lg border border-line mt-10" />
      )}

      <div className="mt-12 space-y-10">
        {blocks.map(
          ({ key, label }) =>
            project[key] && (
              <div key={key}>
                <p className="eyebrow mb-3">{label}</p>
                <p className="text-ink leading-relaxed whitespace-pre-line">{project[key]}</p>
              </div>
            )
        )}
      </div>
    </article>
  );
};

export default ProjectDetail;
