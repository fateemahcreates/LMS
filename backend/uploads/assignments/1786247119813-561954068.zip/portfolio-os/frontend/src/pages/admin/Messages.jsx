import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiMail, FiCheckCircle, FiArchive } from "react-icons/fi";

const Messages = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const load = () => {
    setLoading(true);
    api.get("/messages", { params: filter !== "all" ? { status: filter } : {} })
      .then((res) => setMessages(res.data.data))
      .finally(() => setLoading(false));
  };
  useEffect(load, [filter]);

  const markRead = async (m) => {
    if (m.status === "read") return;
    await api.put(`/messages/${m._id}`, { status: "read" });
    load();
  };

  const archive = async (id) => {
    await api.put(`/messages/${id}`, { status: "archived" });
    load();
  };

  const remove = async (id) => {
    await api.delete(`/messages/${id}`);
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="eyebrow mb-2">inbox</p>
          <h1 className="font-display text-3xl font-semibold">Messages</h1>
        </div>
        <div className="flex gap-2 font-mono text-xs">
          {["all", "unread", "read", "archived"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-md border ${filter === f ? "border-amber text-amber" : "border-line text-muted"}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {loading ? <Loader label="loading messages" /> : (
        <div className="panel divide-y divide-line">
          {messages.length === 0 && <p className="p-6 text-muted font-mono text-sm">No messages here.</p>}
          {messages.map((m) => (
            <div key={m._id} className="p-4" onClick={() => markRead(m)}>
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    {m.status === "unread" ? <FiMail className="text-amber shrink-0" /> : <FiCheckCircle className="text-muted shrink-0" />}
                    <p className="font-medium truncate">{m.name}</p>
                    <span className="text-muted text-xs font-mono">{m.email}</span>
                  </div>
                  <p className="text-sm text-muted mt-1">{m.subject || "No subject"}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <span className="font-mono text-xs text-muted">{new Date(m.createdAt).toLocaleDateString()}</span>
                  {m.status !== "archived" && (
                    <button onClick={() => archive(m._id)} className="text-muted hover:text-amber" aria-label="Archive">
                      <FiArchive />
                    </button>
                  )}
                  <ConfirmButton onConfirm={() => remove(m._id)} />
                </div>
              </div>
              <p className="text-sm text-ink mt-3">{m.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Messages;
