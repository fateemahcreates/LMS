import { useEffect, useState } from "react";
import api from "../../services/api.js";
import BlogCard from "../../components/BlogCard.jsx";
import SectionHeading from "../../components/SectionHeading.jsx";
import Loader from "../../components/Loader.jsx";
import { FiSearch } from "react-icons/fi";

const Blog = () => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => {
      api.get("/blogs", { params: search ? { search } : {} }).then((res) => setBlogs(res.data.data)).finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(timeout);
  }, [search]);

  return (
    <div className="container-shell py-20">
      <SectionHeading eyebrow="writing" title="Blog" description="Notes on architecture, tooling, and building things end to end." />

      <div className="relative max-w-md mb-10">
        <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
        <input
          type="text"
          placeholder="Search posts..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-surface border border-line rounded-md pl-10 pr-4 py-2.5 text-sm focus:border-amber outline-none"
        />
      </div>

      {loading ? (
        <Loader label="loading posts" />
      ) : blogs.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-6">
          {blogs.map((b) => <BlogCard key={b._id} blog={b} />)}
        </div>
      ) : (
        <p className="font-mono text-muted">no posts yet — check back soon</p>
      )}
    </div>
  );
};

export default Blog;
