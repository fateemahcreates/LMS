import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiArrowRight } from "react-icons/fi";
import api from "../../services/api.js";
import ProjectCard from "../../components/ProjectCard.jsx";
import BlogCard from "../../components/BlogCard.jsx";
import SectionHeading from "../../components/SectionHeading.jsx";
import SkeletonCard from "../../components/SkeletonCard.jsx";

const bootLines = [
  "$ whoami",
  "> full-stack developer",
  "$ status --check",
  "> available for opportunities",
  "$ uptime",
  "> shipping since 2023",
];

const Home = () => {
  const [projects, setProjects] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [skills, setSkills] = useState([]);
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [visibleLines, setVisibleLines] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisibleLines((v) => (v < bootLines.length ? v + 1 : v));
    }, 350);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    Promise.all([
      api.get("/projects", { params: { featured: true } }),
      api.get("/blogs"),
      api.get("/skills"),
      api.get("/testimonials"),
    ])
      .then(([p, b, s, t]) => {
        setProjects(p.data.data.slice(0, 3));
        setBlogs(b.data.data.slice(0, 2));
        setSkills(s.data.data.slice(0, 8));
        setTestimonials(t.data.data.slice(0, 2));
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative border-b border-line bg-grid bg-grid overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-base/60 to-base pointer-events-none" />
        <div className="container-shell relative py-24 md:py-32 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="eyebrow mb-4">system online</p>
            <h1 className="font-display text-4xl md:text-6xl font-semibold leading-[1.05] tracking-tight">
              Building software
              <br />
              that <span className="text-amber">ships</span>, not just
              <br />
              slides.
            </h1>
            <p className="text-muted mt-6 max-w-md">
              Full-stack developer portfolio, run on its own content system —
              every project below was pushed live through the dashboard, not a redeploy.
            </p>
            <div className="flex flex-wrap gap-4 mt-8">
              <Link to="/projects" className="btn-primary">
                View projects <FiArrowRight />
              </Link>
              <Link to="/contact" className="btn-ghost">Get in touch</Link>
            </div>
          </div>

          <div className="panel p-6 font-mono text-sm">
            <div className="flex gap-1.5 mb-4">
              <span className="w-3 h-3 rounded-full bg-bad/70" />
              <span className="w-3 h-3 rounded-full bg-amber/70" />
              <span className="w-3 h-3 rounded-full bg-good/70" />
            </div>
            <div className="space-y-1.5 min-h-[168px]">
              {bootLines.slice(0, visibleLines).map((line, i) => (
                <p key={i} className={line.startsWith(">") ? "text-good pl-4" : "text-ink"}>
                  {line}
                </p>
              ))}
              {visibleLines < bootLines.length && <span className="inline-block w-2 h-4 bg-amber animate-pulse" />}
            </div>
          </div>
        </div>
      </section>

      {/* Featured projects */}
      <section className="container-shell py-20">
        <SectionHeading
          eyebrow="featured work"
          title="Recent projects"
          description="A few things built end-to-end — architecture, implementation, and the outcomes that came from shipping them."
        />
        <div className="grid md:grid-cols-3 gap-6">
          {loading
            ? Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)
            : projects.map((p) => <ProjectCard key={p._id} project={p} />)}
        </div>
        <div className="mt-8">
          <Link to="/projects" className="font-mono text-sm text-amber hover:text-amber-soft inline-flex items-center gap-2">
            all projects <FiArrowRight />
          </Link>
        </div>
      </section>

      {/* Skills */}
      {!loading && skills.length > 0 && (
        <section className="border-t border-line bg-surface/40">
          <div className="container-shell py-20">
            <SectionHeading eyebrow="tech stack" title="Tools I reach for" />
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
              {skills.map((s) => (
                <div key={s._id} className="panel p-4">
                  <div className="flex justify-between font-mono text-xs text-muted mb-2">
                    <span className="text-ink font-medium">{s.name}</span>
                    <span>{s.level}%</span>
                  </div>
                  <div className="h-1.5 bg-raised rounded-full overflow-hidden">
                    <div className="h-full bg-amber rounded-full" style={{ width: `${s.level}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Testimonials */}
      {!loading && testimonials.length > 0 && (
        <section className="container-shell py-20">
          <SectionHeading eyebrow="feedback" title="What people say" />
          <div className="grid md:grid-cols-2 gap-6">
            {testimonials.map((t) => (
              <div key={t._id} className="panel p-6">
                <p className="text-ink leading-relaxed">&ldquo;{t.review}&rdquo;</p>
                <p className="mt-4 font-mono text-sm text-muted">
                  {t.name}{t.company ? ` — ${t.position ? t.position + ", " : ""}${t.company}` : ""}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Latest blog */}
      {!loading && blogs.length > 0 && (
        <section className="border-t border-line bg-surface/40">
          <div className="container-shell py-20">
            <SectionHeading eyebrow="writing" title="Latest from the blog" />
            <div className="grid md:grid-cols-2 gap-6">
              {blogs.map((b) => <BlogCard key={b._id} blog={b} />)}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="container-shell py-24 text-center">
        <p className="eyebrow justify-center mb-4">let's talk</p>
        <h2 className="font-display text-3xl md:text-4xl font-semibold">Have a project in mind?</h2>
        <p className="text-muted mt-3 max-w-lg mx-auto">
          Open to full-time roles, contract work, and interesting problems.
        </p>
        <Link to="/contact" className="btn-primary mt-8 inline-flex">
          Start a conversation <FiArrowRight />
        </Link>
      </section>
    </div>
  );
};

export default Home;
