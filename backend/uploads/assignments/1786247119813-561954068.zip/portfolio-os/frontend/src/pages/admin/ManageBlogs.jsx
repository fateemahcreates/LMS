import { useEffect, useState } from "react";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import ImageUpload from "../../components/ImageUpload.jsx";
import ConfirmButton from "../../components/ConfirmButton.jsx";
import { FiPlus, FiEdit2, FiX } from "react-icons/fi";

const emptyForm = { title: "", content: "", excerpt: "", coverImage: "", tags: "", category: "General", published: false };

const ManageBlogs = () => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    api.get("/blogs", { params: { admin: true } }).then((res) => setBlogs(res.data.data)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openNew = () => { setForm(emptyForm); setEditing({}); };
  const openEdit = (b) => { setForm({ ...b, tags: (b.tags || []).join(", ") }); setEditing(b); };
  const close = () => setEditing(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = { ...form, tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean) };
    try {
      if (editing?._id) await api.put(`/blogs/${editing._id}`, payload);
      else await api.post("/blogs", payload);
      close();
      load();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => { await api.delete(`/blogs/${id}`); load(); };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="eyebrow mb-2">blog</p>
          <h1 className="font-display text-3xl font-semibold">Manage posts</h1>
        </div>
        <button onClick={openNew} className="btn-primary"><FiPlus /> New post</button>
      </div>

      {loading ? <Loader label="loading posts" /> : (
        <div className="panel divide-y divide-line">
          {blogs.length === 0 && <p className="p-6 text-muted font-mono text-sm">No posts yet.</p>}
          {blogs.map((b) => (
            <div key={b._id} className="flex items-center justify-between p-4 gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium truncate">{b.title}</p>
                  <span className={`tag ${b.published ? "text-good border-good/40" : ""}`}>{b.published ? "published" : "draft"}</span>
                </div>
                <p className="text-muted text-sm truncate">{b.category} · {b.readingTime} min read · {b.views} views</p>
              </div>
              <div className="flex items-center gap-4 shrink-0">
                <button onClick={() => openEdit(b)} className="text-muted hover:text-amber"><FiEdit2 /></button>
                <ConfirmButton onConfirm={() => handleDelete(b._id)} />
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== null && (
        <div className="fixed inset-0 bg-base/80 backdrop-blur-sm flex items-start justify-center overflow-y-auto z-50 p-6">
          <form onSubmit={handleSubmit} className="panel p-6 w-full max-w-2xl my-8 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="font-display text-xl font-semibold">{editing?._id ? "Edit post" : "New post"}</h2>
              <button type="button" onClick={close} className="text-muted hover:text-ink"><FiX /></button>
            </div>

            <div>
              <label className="text-xs font-mono text-muted">Title</label>
              <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>

            <div>
              <label className="text-xs font-mono text-muted">Excerpt</label>
              <input value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
            </div>

            <div>
              <label className="text-xs font-mono text-muted">Content (Markdown supported)</label>
              <textarea required rows={8} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })}
                className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm font-mono focus:border-amber outline-none" />
            </div>

            <ImageUpload value={form.coverImage} onChange={(url) => setForm({ ...form, coverImage: url })} label="Cover image" />

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-muted">Tags (comma separated)</label>
                <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
              <div>
                <label className="text-xs font-mono text-muted">Category</label>
                <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full bg-raised border border-line rounded-md px-3 py-2.5 mt-1 text-sm focus:border-amber outline-none" />
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} />
              Published
            </label>

            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={close} className="btn-ghost">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
                {saving ? "Saving..." : "Save post"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageBlogs;
