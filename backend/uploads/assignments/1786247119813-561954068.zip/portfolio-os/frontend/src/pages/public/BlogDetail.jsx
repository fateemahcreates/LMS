import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import api from "../../services/api.js";
import Loader from "../../components/Loader.jsx";
import { FiArrowLeft, FiClock } from "react-icons/fi";

const BlogDetail = () => {
  const { slug } = useParams();
  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/blogs/${slug}`).then((res) => setBlog(res.data.data)).finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <Loader label="loading post" />;
  if (!blog) {
    return <div className="container-shell py-24 text-center font-mono text-muted">post not found</div>;
  }

  return (
    <article className="container-shell py-16 max-w-2xl">
      <Link to="/blog" className="font-mono text-sm text-muted hover:text-amber inline-flex items-center gap-2 mb-8">
        <FiArrowLeft /> all posts
      </Link>

      <p className="eyebrow mb-3">{blog.category}</p>
      <h1 className="font-display text-4xl font-semibold leading-tight">{blog.title}</h1>
      <div className="flex items-center gap-4 font-mono text-xs text-muted mt-4">
        <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
        <span className="flex items-center gap-1"><FiClock /> {blog.readingTime} min read</span>
        <span>{blog.views} views</span>
      </div>

      {blog.coverImage && (
        <img src={blog.coverImage} alt={blog.title} className="w-full rounded-lg border border-line mt-8" />
      )}

      <div className="prose-invert mt-10 leading-relaxed text-ink [&_h2]:font-display [&_h2]:text-2xl [&_h2]:mt-8 [&_h2]:mb-3 [&_p]:mb-4 [&_a]:text-amber [&_code]:font-mono [&_code]:text-sm [&_code]:bg-surface [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:mb-4">
        <ReactMarkdown remarkPlugins={[remarkGfm]}>{blog.content}</ReactMarkdown>
      </div>

      {blog.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-10 pt-6 border-t border-line">
          {blog.tags.map((t) => <span key={t} className="tag">#{t}</span>)}
        </div>
      )}
    </article>
  );
};

export default BlogDetail;
