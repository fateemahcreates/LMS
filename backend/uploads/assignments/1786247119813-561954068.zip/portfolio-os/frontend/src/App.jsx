import { Routes, Route } from "react-router-dom";

import PublicLayout from "./layouts/PublicLayout.jsx";
import AdminLayout from "./layouts/AdminLayout.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Home from "./pages/public/Home.jsx";
import About from "./pages/public/About.jsx";
import Projects from "./pages/public/Projects.jsx";
import ProjectDetail from "./pages/public/ProjectDetail.jsx";
import Blog from "./pages/public/Blog.jsx";
import BlogDetail from "./pages/public/BlogDetail.jsx";
import Contact from "./pages/public/Contact.jsx";
import Resume from "./pages/public/Resume.jsx";
import NotFound from "./pages/public/NotFound.jsx";

import Login from "./pages/admin/Login.jsx";
import DashboardHome from "./pages/admin/DashboardHome.jsx";
import ManageProjects from "./pages/admin/ManageProjects.jsx";
import ManageBlogs from "./pages/admin/ManageBlogs.jsx";
import ManageSkills from "./pages/admin/ManageSkills.jsx";
import ManageExperience from "./pages/admin/ManageExperience.jsx";
import ManageCertificates from "./pages/admin/ManageCertificates.jsx";
import ManageTestimonials from "./pages/admin/ManageTestimonials.jsx";
import Messages from "./pages/admin/Messages.jsx";

function App() {
  return (
    <Routes>
      {/* Public site */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/projects/:slug" element={<ProjectDetail />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:slug" element={<BlogDetail />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/resume" element={<Resume />} />
      </Route>

      {/* Admin auth */}
      <Route path="/admin/login" element={<Login />} />

      {/* Admin dashboard */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardHome />} />
        <Route path="projects" element={<ManageProjects />} />
        <Route path="blogs" element={<ManageBlogs />} />
        <Route path="skills" element={<ManageSkills />} />
        <Route path="experience" element={<ManageExperience />} />
        <Route path="certificates" element={<ManageCertificates />} />
        <Route path="testimonials" element={<ManageTestimonials />} />
        <Route path="messages" element={<Messages />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
