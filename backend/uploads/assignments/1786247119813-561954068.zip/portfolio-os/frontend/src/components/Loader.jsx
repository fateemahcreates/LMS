const Loader = ({ label = "loading" }) => (
  <div className="flex items-center justify-center py-24">
    <div className="font-mono text-sm text-muted flex items-center gap-2">
      <span className="w-2 h-2 rounded-full bg-amber animate-pulse" />
      {label}...
    </div>
  </div>
);

export default Loader;
