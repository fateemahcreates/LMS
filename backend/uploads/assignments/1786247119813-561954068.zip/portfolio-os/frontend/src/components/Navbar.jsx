import { useState, useEffect } from "react";
import { NavLink, Link } from "react-router-dom";
import { HiOutlineMenu, HiOutlineX } from "react-icons/hi";

const links = [
  { to: "/", label: "home" },
  { to: "/about", label: "about" },
  { to: "/projects", label: "projects" },
  { to: "/blog", label: "blog" },
  { to: "/contact", label: "contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 border-b transition-colors duration-200 ${
        scrolled ? "bg-base/90 backdrop-blur border-line" : "bg-transparent border-transparent"
      }`}
    >
      <nav className="container-shell flex items-center justify-between h-16">
        <Link to="/" className="font-display font-semibold text-lg tracking-tight">
          portfolio<span className="text-amber">OS</span>
          <span className="ml-2 inline-block w-2 h-2 rounded-full bg-good align-middle animate-pulse" />
        </Link>

        <div className="hidden md:flex items-center gap-8 font-mono text-sm">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                `transition-colors ${isActive ? "text-amber" : "text-muted hover:text-ink"}`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <button
          className="md:hidden text-ink text-2xl"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {open ? <HiOutlineX /> : <HiOutlineMenu />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-line bg-base">
          <div className="container-shell flex flex-col gap-4 py-4 font-mono text-sm">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                onClick={() => setOpen(false)}
                className={({ isActive }) => (isActive ? "text-amber" : "text-muted")}
              >
                {l.label}
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
