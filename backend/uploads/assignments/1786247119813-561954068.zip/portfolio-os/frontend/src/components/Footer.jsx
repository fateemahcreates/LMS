import { Link } from "react-router-dom";
import { FiGithub, FiLinkedin, FiTwitter, FiMail } from "react-icons/fi";

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-line mt-24">
      <div className="container-shell py-12 grid gap-8 md:grid-cols-3">
        <div>
          <p className="font-display font-semibold text-lg">
            portfolio<span className="text-amber">OS</span>
          </p>
          <p className="text-muted text-sm mt-2 max-w-xs">
            A developer portfolio and content system, built to be updated as fast as it ships.
          </p>
        </div>

        <div className="font-mono text-sm text-muted flex flex-col gap-2">
          <span className="eyebrow">sitemap</span>
          <Link to="/projects" className="hover:text-amber transition-colors">projects</Link>
          <Link to="/blog" className="hover:text-amber transition-colors">blog</Link>
          <Link to="/resume" className="hover:text-amber transition-colors">resume</Link>
          <Link to="/contact" className="hover:text-amber transition-colors">contact</Link>
        </div>

        <div className="flex md:justify-end items-start gap-4 text-xl text-muted">
          <a href="#" aria-label="Github" className="hover:text-amber transition-colors"><FiGithub /></a>
          <a href="#" aria-label="LinkedIn" className="hover:text-amber transition-colors"><FiLinkedin /></a>
          <a href="#" aria-label="Twitter" className="hover:text-amber transition-colors"><FiTwitter /></a>
          <a href="#" aria-label="Email" className="hover:text-amber transition-colors"><FiMail /></a>
        </div>
      </div>
      <div className="border-t border-line">
        <div className="container-shell py-4 text-xs font-mono text-muted flex justify-between">
          <span>© {year} portfolioOS</span>
          <span>status: <span className="text-good">online</span></span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
