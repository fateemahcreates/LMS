import { useState } from "react";
import api from "../services/api.js";
import { FiUploadCloud } from "react-icons/fi";

// Uploads to the backend's local disk storage and returns a relative /uploads
// URL. Swap this component's onUpload logic for Cloudinary later without
// touching any of the forms that use it.
const ImageUpload = ({ value, onChange, label = "Image" }) => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError("");
    try {
      const formData = new FormData();
      formData.append("image", file);
      const res = await api.post("/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      onChange(res.data.data.url);
    } catch (err) {
      setError(err.response?.data?.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <label className="text-xs font-mono text-muted">{label}</label>
      <div className="flex items-center gap-3 mt-1">
        {value && <img src={value} alt="preview" className="w-16 h-16 object-cover rounded-md border border-line" />}
        <label className="flex-1 flex items-center justify-center gap-2 border border-dashed border-line rounded-md py-3 text-sm text-muted cursor-pointer hover:border-amber hover:text-amber transition-colors">
          <FiUploadCloud />
          {uploading ? "Uploading..." : "Upload image"}
          <input type="file" accept="image/*" className="hidden" onChange={handleFile} disabled={uploading} />
        </label>
      </div>
      {error && <p className="text-bad text-xs mt-1">{error}</p>}
    </div>
  );
};

export default ImageUpload;
