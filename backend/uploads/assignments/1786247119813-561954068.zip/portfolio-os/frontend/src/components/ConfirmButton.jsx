import { useState } from "react";
import { FiTrash2 } from "react-icons/fi";

// Simple two-click confirm to avoid native window.confirm dialogs, which
// look out of place next to a designed admin console.
const ConfirmButton = ({ onConfirm, label = "" }) => {
  const [confirming, setConfirming] = useState(false);

  if (confirming) {
    return (
      <div className="flex items-center gap-2 text-xs font-mono">
        <button
          onClick={() => {
            setConfirming(false);
            onConfirm();
          }}
          className="text-bad hover:underline"
        >
          confirm
        </button>
        <button onClick={() => setConfirming(false)} className="text-muted hover:underline">
          cancel
        </button>
      </div>
    );
  }

  return (
    <button onClick={() => setConfirming(true)} className="text-muted hover:text-bad transition-colors" aria-label="Delete">
      <FiTrash2 /> {label}
    </button>
  );
};

export default ConfirmButton;
