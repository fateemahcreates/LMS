const SkeletonCard = () => (
  <div className="panel p-5 animate-pulse">
    <div className="h-40 bg-raised rounded-md mb-4" />
    <div className="h-4 bg-raised rounded w-3/4 mb-2" />
    <div className="h-3 bg-raised rounded w-1/2" />
  </div>
);

export default SkeletonCard;
