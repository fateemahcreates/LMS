const SectionHeading = ({ eyebrow, title, description }) => (
  <div className="mb-10">
    {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
    <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight">{title}</h2>
    {description && <p className="text-muted mt-3 max-w-2xl">{description}</p>}
  </div>
);

export default SectionHeading;
