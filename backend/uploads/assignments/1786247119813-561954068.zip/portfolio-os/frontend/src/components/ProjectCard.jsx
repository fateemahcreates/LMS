import { Link } from "react-router-dom";
import { FiArrowUpRight, FiEye, FiHeart } from "react-icons/fi";

const ProjectCard = ({ project }) => (
  <Link
    to={`/projects/${project.slug}`}
    className="group panel overflow-hidden hover:border-amber transition-colors duration-200 flex flex-col"
  >
    <div className="h-44 bg-raised bg-grid bg-grid relative overflow-hidden">
      {project.coverImage ? (
        <img
          src={project.coverImage}
          alt={project.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center font-mono text-xs text-muted">
          no preview
        </div>
      )}
      {project.featured && (
        <span className="absolute top-3 left-3 tag bg-base/80 text-amber border-amber/40">featured</span>
      )}
    </div>

    <div className="p-5 flex flex-col gap-3 flex-1">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-display font-semibold text-lg leading-snug">{project.title}</h3>
        <FiArrowUpRight className="text-muted group-hover:text-amber transition-colors shrink-0 mt-1" />
      </div>
      <p className="text-muted text-sm line-clamp-2">{project.description}</p>

      <div className="flex flex-wrap gap-2 mt-auto pt-2">
        {project.techStack?.slice(0, 4).map((t) => (
          <span key={t} className="tag">{t}</span>
        ))}
      </div>

      <div className="flex items-center gap-4 text-xs font-mono text-muted pt-2 border-t border-line">
        <span className="flex items-center gap-1"><FiEye /> {project.views ?? 0}</span>
        <span className="flex items-center gap-1"><FiHeart /> {project.likes ?? 0}</span>
        <span className="ml-auto">{project.category}</span>
      </div>
    </div>
  </Link>
);

export default ProjectCard;
