import { Link } from "react-router-dom";
import { FiClock } from "react-icons/fi";

const BlogCard = ({ blog }) => (
  <Link to={`/blog/${blog.slug}`} className="group panel p-5 flex flex-col gap-3 hover:border-amber transition-colors">
    <div className="flex items-center gap-3 font-mono text-xs text-muted">
      <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
      <span className="flex items-center gap-1"><FiClock /> {blog.readingTime} min read</span>
    </div>
    <h3 className="font-display font-semibold text-lg group-hover:text-amber transition-colors">{blog.title}</h3>
    <p className="text-muted text-sm line-clamp-3">{blog.excerpt || blog.content?.slice(0, 140)}</p>
    <div className="flex flex-wrap gap-2 pt-2">
      {blog.tags?.slice(0, 3).map((t) => (
        <span key={t} className="tag">#{t}</span>
      ))}
    </div>
  </Link>
);

export default BlogCard;
