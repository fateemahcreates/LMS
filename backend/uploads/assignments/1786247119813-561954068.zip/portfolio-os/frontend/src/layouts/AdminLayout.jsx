import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import {
  FiGrid, FiFolder, FiFileText, FiAward, FiBriefcase, FiMessageSquare,
  FiStar, FiLogOut,
} from "react-icons/fi";

const links = [
  { to: "/admin", label: "Overview", icon: FiGrid, end: true },
  { to: "/admin/projects", label: "Projects", icon: FiFolder },
  { to: "/admin/blogs", label: "Blog", icon: FiFileText },
  { to: "/admin/skills", label: "Skills", icon: FiAward },
  { to: "/admin/experience", label: "Experience", icon: FiBriefcase },
  { to: "/admin/certificates", label: "Certificates", icon: FiAward },
  { to: "/admin/testimonials", label: "Testimonials", icon: FiStar },
  { to: "/admin/messages", label: "Messages", icon: FiMessageSquare },
];

const AdminLayout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen flex bg-base">
      <aside className="w-64 shrink-0 border-r border-line hidden md:flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-line">
          <span className="font-display font-semibold">
            portfolio<span className="text-amber">OS</span>
          </span>
        </div>
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1 font-mono text-sm">
          {links.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  isActive ? "bg-raised text-amber" : "text-muted hover:text-ink hover:bg-raised/50"
                }`
              }
            >
              <Icon /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-line">
          <div className="flex items-center justify-between">
            <div className="text-sm">
              <p className="font-medium">{user?.name}</p>
              <p className="text-muted text-xs font-mono">{user?.email}</p>
            </div>
            <button onClick={handleLogout} aria-label="Log out" className="text-muted hover:text-bad transition-colors">
              <FiLogOut />
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="md:hidden h-14 border-b border-line flex items-center justify-between px-4">
          <span className="font-display font-semibold">
            portfolio<span className="text-amber">OS</span>
          </span>
          <button onClick={handleLogout} className="text-muted"><FiLogOut /></button>
        </header>
        <div className="p-6 md:p-10">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
