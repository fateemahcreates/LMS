# PortfolioOS

A full-stack developer portfolio with its own content management system —
update projects, blog posts, skills, experience, certificates and testimonials
through an admin dashboard instead of redeploying code.

This is the v1 scope agreed on earlier: real auth, real CRUD, a working public
site and admin console. It intentionally leaves out the "future features" tier
from the SDD (AI resume reviewer, LeetCode/Codeforces integration, portfolio
builder/export, multi-language) — those are v2.

## Stack

- **Frontend:** React + Vite, React Router, Tailwind CSS, React Hook Form, Recharts, React Markdown
- **Backend:** Node.js, Express, MongoDB (Mongoose), JWT auth, Multer (local image uploads)

## Project structure

```
portfolio-os/
├── frontend/     React + Vite app (public site + admin dashboard)
└── backend/      Express API + MongoDB models
```

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:
- `MONGO_URI` — your MongoDB Atlas (or local) connection string
- `JWT_SECRET` — any long random string
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — credentials for the seeded admin account

Seed the database (creates the admin user + a few sample projects, skills,
experience and testimonials so the site isn't empty on first run):

```bash
npm run seed
```

Start the API:

```bash
npm run dev
```

The API runs on `http://localhost:5000` by default. Uploaded images are
stored on disk under `backend/uploads` and served from `/uploads/*`.

## 2. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

The app runs on `http://localhost:5173` and proxies `/api` and `/uploads`
requests to the backend during development (see `vite.config.js`).

## 3. Log into the dashboard

Visit `http://localhost:5173/admin/login` and sign in with the
`ADMIN_EMAIL` / `ADMIN_PASSWORD` you set in `backend/.env`.

From there you can manage:
- **Projects** — full case studies (problem / architecture / implementation / outcomes), tech stack, cover image, GitHub + live demo links, draft/published status, featured toggle
- **Blog** — Markdown posts with tags, category, cover image, reading time auto-calculated
- **Skills** — grouped by category with a proficiency level and years of experience
- **Experience** — career timeline entries with technologies and achievements
- **Certificates** — issuing organization, credential link, issue/expiry dates
- **Testimonials** — client reviews with rating, shown/hidden on the public site
- **Messages** — inbox for the public contact form, with read/archive/delete

## Notes on scope and swap-in points

- **Image uploads** currently save to local disk (`backend/uploads`) via Multer, not Cloudinary. This avoids requiring API keys to run the project locally. To switch to Cloudinary later, replace the logic in `backend/middleware/upload.js` and `backend/routes/uploadRoutes.js` — nothing in the frontend forms needs to change, since they just call `POST /api/upload` and store whatever URL comes back.
- **View counters** on projects/blogs increment on every fetch by slug. For production, consider debouncing by IP/session so refreshes don't inflate the count.
- **Resume PDF download** on the `/resume` page links to `/resume.pdf` — drop your actual resume file into `frontend/public/resume.pdf` (create that folder) for the download button to work.
- **Deployment:** frontend is a static Vite build (deploy to Vercel/Netlify), backend is a standard Express app (deploy to Render/Railway/Fly). Set `CLIENT_URL` on the backend and `VITE_API_URL` on the frontend to your deployed URLs.

## What's deliberately not built (v2 / future features)

AI resume reviewer, AI chat assistant, visitor auth, project bookmarking,
newsletter, admin activity logs, multi-language support, portfolio themes,
portfolio builder/export, GitHub/LeetCode/Codeforces/Dev.to/Medium
integrations, RSS feed. These were flagged as scope risks in the original
design review — build the core platform first, then layer these in.
