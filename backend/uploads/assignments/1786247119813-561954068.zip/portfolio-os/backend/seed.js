// Seeds an admin user and a small set of sample content so the site isn't
// empty on first run. Safe to re-run - it upserts the admin and skips
// content seeding if data already exists.
//
// Usage: npm run seed   (reads .env for ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD)

import dotenv from "dotenv";
dotenv.config();

import connectDB from "./config/db.js";
import User from "./models/User.js";
import Project from "./models/Project.js";
import Blog from "./models/Blog.js";
import Skill from "./models/Skill.js";
import Experience from "./models/Experience.js";
import Testimonial from "./models/Testimonial.js";

const run = async () => {
  await connectDB();

  const adminEmail = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase();
  let admin = await User.findOne({ email: adminEmail });
  if (!admin) {
    admin = await User.create({
      name: process.env.ADMIN_NAME || "Admin",
      email: adminEmail,
      password: process.env.ADMIN_PASSWORD || "ChangeMe123!",
      role: "admin",
    });
    console.log(`Created admin user: ${admin.email}`);
  } else {
    console.log(`Admin user already exists: ${admin.email}`);
  }

  const projectCount = await Project.countDocuments();
  if (projectCount === 0) {
    await Project.create([
      {
        title: "PortfolioOS",
        description: "A full-stack developer portfolio and CMS with a JWT-secured dashboard.",
        problem: "Static portfolios can't be updated without redeploying code.",
        architecture: "React/Vite frontend, Express/MongoDB backend, JWT auth, Multer uploads.",
        implementation: "Built a REST API with role-gated CRUD across projects, blogs, skills and messages.",
        outcomes: "Content updates ship in seconds through the admin dashboard, no redeploy required.",
        techStack: ["React", "Node.js", "Express", "MongoDB", "Tailwind CSS"],
        category: "Full Stack",
        featured: true,
        status: "published",
      },
      {
        title: "BlogSphere",
        description: "A full-stack blogging platform with an AI writing assistant.",
        techStack: ["React", "TypeScript", "Node.js", "Prisma", "MongoDB"],
        category: "Full Stack",
        featured: true,
        status: "published",
      },
    ]);
    console.log("Seeded sample projects");
  }

  const blogCount = await Blog.countDocuments();
  if (blogCount === 0) {
    await Blog.create([
      {
        title: "Designing a CMS-driven portfolio instead of a static one",
        content:
          "Most developer portfolios are static sites rebuilt on every change. This post walks through why a small CMS pays for itself once you're shipping projects regularly, and how the data model was structured to keep the admin dashboard simple.",
        excerpt: "Why a lightweight CMS beats a static rebuild for a developer portfolio.",
        tags: ["architecture", "cms"],
        category: "Engineering",
        published: true,
      },
    ]);
    console.log("Seeded sample blog post");
  }

  const skillCount = await Skill.countDocuments();
  if (skillCount === 0) {
    await Skill.create([
      { name: "React", category: "Frontend", level: 90, yearsExperience: 3, order: 1 },
      { name: "TypeScript", category: "Frontend", level: 85, yearsExperience: 2, order: 2 },
      { name: "Node.js", category: "Backend", level: 88, yearsExperience: 3, order: 3 },
      { name: "MongoDB", category: "Database", level: 80, yearsExperience: 3, order: 4 },
      { name: "Express", category: "Backend", level: 85, yearsExperience: 3, order: 5 },
      { name: "Tailwind CSS", category: "Frontend", level: 90, yearsExperience: 2, order: 6 },
    ]);
    console.log("Seeded sample skills");
  }

  const expCount = await Experience.countDocuments();
  if (expCount === 0) {
    await Experience.create([
      {
        company: "Freelance",
        position: "Full Stack Developer",
        startDate: new Date("2023-01-01"),
        current: true,
        description: "Designing and shipping full-stack web applications end to end.",
        technologies: ["React", "Node.js", "MongoDB"],
        achievements: ["Shipped BlogSphere, a full-stack blogging platform with AI-assisted writing"],
        order: 1,
      },
    ]);
    console.log("Seeded sample experience");
  }

  const testimonialCount = await Testimonial.countDocuments();
  if (testimonialCount === 0) {
    await Testimonial.create([
      {
        name: "Sample Client",
        company: "Example Co",
        position: "Product Manager",
        rating: 5,
        review: "Replace this with a real testimonial once you have one - delete it from the dashboard otherwise.",
      },
    ]);
    console.log("Seeded sample testimonial");
  }

  console.log("Seed complete.");
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
