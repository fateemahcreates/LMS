import Testimonial from "../models/Testimonial.js";
import { getAll, getOne, createOne, updateOne, deleteOne } from "./crudFactory.js";

export const getTestimonials = getAll(Testimonial, "-createdAt");
export const getTestimonial = getOne(Testimonial);
export const createTestimonial = createOne(Testimonial);
export const updateTestimonial = updateOne(Testimonial);
export const deleteTestimonial = deleteOne(Testimonial);
