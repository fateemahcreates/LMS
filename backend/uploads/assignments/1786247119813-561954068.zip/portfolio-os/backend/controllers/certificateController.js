import Certificate from "../models/Certificate.js";
import { getAll, getOne, createOne, updateOne, deleteOne } from "./crudFactory.js";

export const getCertificates = getAll(Certificate, "-issueDate");
export const getCertificate = getOne(Certificate);
export const createCertificate = createOne(Certificate);
export const updateCertificate = updateOne(Certificate);
export const deleteCertificate = deleteOne(Certificate);
