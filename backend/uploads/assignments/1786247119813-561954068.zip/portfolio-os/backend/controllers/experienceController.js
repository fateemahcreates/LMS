import Experience from "../models/Experience.js";
import { getAll, getOne, createOne, updateOne, deleteOne } from "./crudFactory.js";

export const getExperiences = getAll(Experience, "-startDate");
export const getExperience = getOne(Experience);
export const createExperience = createOne(Experience);
export const updateExperience = updateOne(Experience);
export const deleteExperience = deleteOne(Experience);
