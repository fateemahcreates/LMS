import Skill from "../models/Skill.js";
import { getAll, getOne, createOne, updateOne, deleteOne } from "./crudFactory.js";

export const getSkills = getAll(Skill, "order name");
export const getSkill = getOne(Skill);
export const createSkill = createOne(Skill);
export const updateSkill = updateOne(Skill);
export const deleteSkill = deleteOne(Skill);
