import Blog from "../models/Blog.js";

// @desc  Public: list blogs (published only, unless admin query)
// @route GET /api/blogs
export const getBlogs = async (req, res, next) => {
  try {
    const { category, tag, search, admin } = req.query;
    const filter = {};
    if (!admin) filter.published = true;
    if (category) filter.category = category;
    if (tag) filter.tags = tag;
    if (search) filter.title = { $regex: search, $options: "i" };

    const blogs = await Blog.find(filter).sort("-createdAt");
    res.json({ success: true, count: blogs.length, data: blogs });
  } catch (err) {
    next(err);
  }
};

// @desc  Public: get one blog by slug, increments views
// @route GET /api/blogs/:slug
export const getBlogBySlug = async (req, res, next) => {
  try {
    const blog = await Blog.findOneAndUpdate(
      { slug: req.params.slug },
      { $inc: { views: 1 } },
      { new: true }
    );
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found" });
    res.json({ success: true, data: blog });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: get single blog by id (for edit forms)
// @route GET /api/blogs/id/:id
export const getBlogById = async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found" });
    res.json({ success: true, data: blog });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: create blog
// @route POST /api/blogs
export const createBlog = async (req, res, next) => {
  try {
    const blog = await Blog.create(req.body);
    res.status(201).json({ success: true, data: blog });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: update blog
// @route PUT /api/blogs/:id
export const updateBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found" });
    res.json({ success: true, data: blog });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: delete blog
// @route DELETE /api/blogs/:id
export const deleteBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findByIdAndDelete(req.params.id);
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found" });
    res.json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};
