import Project from "../models/Project.js";

// @desc  Public: list projects (published only, unless admin query)
// @route GET /api/projects
export const getProjects = async (req, res, next) => {
  try {
    const { category, featured, search, admin } = req.query;
    const filter = {};
    if (!admin) filter.status = "published";
    if (category) filter.category = category;
    if (featured) filter.featured = featured === "true";
    if (search) filter.title = { $regex: search, $options: "i" };

    const projects = await Project.find(filter).sort("-featured -createdAt");
    res.json({ success: true, count: projects.length, data: projects });
  } catch (err) {
    next(err);
  }
};

// @desc  Public: get one project by slug, increments views
// @route GET /api/projects/:slug
export const getProjectBySlug = async (req, res, next) => {
  try {
    const project = await Project.findOneAndUpdate(
      { slug: req.params.slug },
      { $inc: { views: 1 } },
      { new: true }
    );
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: get single project by id (for edit forms)
// @route GET /api/projects/id/:id
export const getProjectById = async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: create project
// @route POST /api/projects
export const createProject = async (req, res, next) => {
  try {
    const project = await Project.create(req.body);
    res.status(201).json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: update project
// @route PUT /api/projects/:id
export const updateProject = async (req, res, next) => {
  try {
    const project = await Project.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: delete project
// @route DELETE /api/projects/:id
export const deleteProject = async (req, res, next) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.id);
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: toggle like (public button, kept simple/no auth for demo purposes)
// @route POST /api/projects/:slug/like
export const likeProject = async (req, res, next) => {
  try {
    const project = await Project.findOneAndUpdate(
      { slug: req.params.slug },
      { $inc: { likes: 1 } },
      { new: true }
    );
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
};
