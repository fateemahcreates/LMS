import Message from "../models/Message.js";

// @desc  Public: submit contact form
// @route POST /api/messages
export const createMessage = async (req, res, next) => {
  try {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ success: false, message: "Name, email and message are required" });
    }
    const doc = await Message.create({ name, email, subject, message });
    res.status(201).json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: list messages
// @route GET /api/messages
export const getMessages = async (req, res, next) => {
  try {
    const { status } = req.query;
    const filter = status ? { status } : {};
    const messages = await Message.find(filter).sort("-createdAt");
    res.json({ success: true, count: messages.length, data: messages });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: update message status (read / archived)
// @route PUT /api/messages/:id
export const updateMessageStatus = async (req, res, next) => {
  try {
    const doc = await Message.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true, runValidators: true }
    );
    if (!doc) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
};

// @desc  Admin: delete message
// @route DELETE /api/messages/:id
export const deleteMessage = async (req, res, next) => {
  try {
    const doc = await Message.findByIdAndDelete(req.params.id);
    if (!doc) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};
