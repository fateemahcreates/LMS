// Generic CRUD controller factory to keep simple resources (Skill, Experience,
// Certificate, Testimonial) consistent without repeating boilerplate.

export const getAll = (Model, defaultSort = "-createdAt") => async (req, res, next) => {
  try {
    const items = await Model.find().sort(defaultSort);
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    next(err);
  }
};

export const getOne = (Model) => async (req, res, next) => {
  try {
    const item = await Model.findById(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (err) {
    next(err);
  }
};

export const createOne = (Model) => async (req, res, next) => {
  try {
    const item = await Model.create(req.body);
    res.status(201).json({ success: true, data: item });
  } catch (err) {
    next(err);
  }
};

export const updateOne = (Model) => async (req, res, next) => {
  try {
    const item = await Model.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (err) {
    next(err);
  }
};

export const deleteOne = (Model) => async (req, res, next) => {
  try {
    const item = await Model.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};
