import Project from "../models/Project.js";
import Blog from "../models/Blog.js";
import Message from "../models/Message.js";
import Testimonial from "../models/Testimonial.js";

// @desc  Admin: aggregate stats for dashboard overview
// @route GET /api/dashboard/stats
export const getStats = async (req, res, next) => {
  try {
    const [
      totalProjects,
      publishedProjects,
      totalBlogs,
      publishedBlogs,
      totalMessages,
      unreadMessages,
      totalTestimonials,
      projectViewsAgg,
      blogViewsAgg,
      topProjects,
      recentMessages,
      recentBlogs,
    ] = await Promise.all([
      Project.countDocuments(),
      Project.countDocuments({ status: "published" }),
      Blog.countDocuments(),
      Blog.countDocuments({ published: true }),
      Message.countDocuments(),
      Message.countDocuments({ status: "unread" }),
      Testimonial.countDocuments(),
      Project.aggregate([{ $group: { _id: null, total: { $sum: "$views" } } }]),
      Blog.aggregate([{ $group: { _id: null, total: { $sum: "$views" } } }]),
      Project.find().sort("-views").limit(5).select("title slug views likes"),
      Message.find().sort("-createdAt").limit(5),
      Blog.find().sort("-createdAt").limit(5).select("title slug published createdAt"),
    ]);

    res.json({
      success: true,
      data: {
        totalProjects,
        publishedProjects,
        totalBlogs,
        publishedBlogs,
        totalMessages,
        unreadMessages,
        totalTestimonials,
        totalProjectViews: projectViewsAgg[0]?.total || 0,
        totalBlogViews: blogViewsAgg[0]?.total || 0,
        topProjects,
        recentMessages,
        recentBlogs,
      },
    });
  } catch (err) {
    next(err);
  }
};
