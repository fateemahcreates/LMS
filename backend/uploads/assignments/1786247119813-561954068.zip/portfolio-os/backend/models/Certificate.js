import mongoose from "mongoose";

const certificateSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    organization: { type: String, required: true },
    image: { type: String, default: "" },
    credentialURL: { type: String, default: "" },
    issueDate: { type: Date, required: true },
    expiryDate: { type: Date },
  },
  { timestamps: true }
);

export default mongoose.model("Certificate", certificateSchema);
