import mongoose from "mongoose";

const testimonialSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    company: { type: String, default: "" },
    position: { type: String, default: "" },
    photo: { type: String, default: "" },
    rating: { type: Number, min: 1, max: 5, default: 5 },
    review: { type: String, required: true },
    approved: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model("Testimonial", testimonialSchema);
