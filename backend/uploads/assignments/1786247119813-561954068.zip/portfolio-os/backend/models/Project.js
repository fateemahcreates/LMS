import mongoose from "mongoose";
import slugify from "slugify";

const projectSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, unique: true },
    description: { type: String, required: true },
    problem: { type: String, default: "" },
    architecture: { type: String, default: "" },
    implementation: { type: String, default: "" },
    outcomes: { type: String, default: "" },
    coverImage: { type: String, default: "" },
    gallery: [{ type: String }],
    github: { type: String, default: "" },
    liveDemo: { type: String, default: "" },
    techStack: [{ type: String }],
    category: { type: String, default: "General" },
    featured: { type: Boolean, default: false },
    status: { type: String, enum: ["draft", "published"], default: "draft" },
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

projectSchema.pre("validate", function (next) {
  if (this.title) {
    this.slug = slugify(this.title, { lower: true, strict: true }) + "-" + Math.random().toString(36).slice(2, 7);
  }
  next();
});

export default mongoose.model("Project", projectSchema);
