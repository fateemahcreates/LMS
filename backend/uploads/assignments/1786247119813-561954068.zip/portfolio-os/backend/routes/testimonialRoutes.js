import express from "express";
import {
  getTestimonials,
  getTestimonial,
  createTestimonial,
  updateTestimonial,
  deleteTestimonial,
} from "../controllers/testimonialController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getTestimonials);
router.get("/:id", getTestimonial);
router.post("/", createTestimonial); // public visitors can submit a testimonial
router.put("/:id", protect, admin, updateTestimonial);
router.delete("/:id", protect, admin, deleteTestimonial);

export default router;
