import express from "express";
import {
  getCertificates,
  getCertificate,
  createCertificate,
  updateCertificate,
  deleteCertificate,
} from "../controllers/certificateController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getCertificates);
router.get("/:id", getCertificate);
router.post("/", protect, admin, createCertificate);
router.put("/:id", protect, admin, updateCertificate);
router.delete("/:id", protect, admin, deleteCertificate);

export default router;
