import express from "express";
import {
  getExperiences,
  getExperience,
  createExperience,
  updateExperience,
  deleteExperience,
} from "../controllers/experienceController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getExperiences);
router.get("/:id", getExperience);
router.post("/", protect, admin, createExperience);
router.put("/:id", protect, admin, updateExperience);
router.delete("/:id", protect, admin, deleteExperience);

export default router;
