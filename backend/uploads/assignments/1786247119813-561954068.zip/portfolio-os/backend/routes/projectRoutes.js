import express from "express";
import {
  getProjects,
  getProjectBySlug,
  getProjectById,
  createProject,
  updateProject,
  deleteProject,
  likeProject,
} from "../controllers/projectController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getProjects);
router.get("/id/:id", protect, admin, getProjectById);
router.post("/", protect, admin, createProject);
router.post("/:slug/like", likeProject);
router.get("/:slug", getProjectBySlug);
router.put("/:id", protect, admin, updateProject);
router.delete("/:id", protect, admin, deleteProject);

export default router;
