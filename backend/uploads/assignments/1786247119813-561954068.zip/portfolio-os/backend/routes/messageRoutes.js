import express from "express";
import {
  createMessage,
  getMessages,
  updateMessageStatus,
  deleteMessage,
} from "../controllers/messageController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.post("/", createMessage);
router.get("/", protect, admin, getMessages);
router.put("/:id", protect, admin, updateMessageStatus);
router.delete("/:id", protect, admin, deleteMessage);

export default router;
