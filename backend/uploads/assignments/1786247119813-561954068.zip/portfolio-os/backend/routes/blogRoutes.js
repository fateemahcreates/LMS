import express from "express";
import {
  getBlogs,
  getBlogBySlug,
  getBlogById,
  createBlog,
  updateBlog,
  deleteBlog,
} from "../controllers/blogController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getBlogs);
router.get("/id/:id", protect, admin, getBlogById);
router.post("/", protect, admin, createBlog);
router.get("/:slug", getBlogBySlug);
router.put("/:id", protect, admin, updateBlog);
router.delete("/:id", protect, admin, deleteBlog);

export default router;
