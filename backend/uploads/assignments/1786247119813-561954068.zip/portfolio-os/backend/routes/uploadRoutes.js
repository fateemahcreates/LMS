import express from "express";
import upload from "../middleware/upload.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

// @desc  Admin: upload an image, returns a relative URL served from /uploads
// @route POST /api/upload
router.post("/", protect, admin, upload.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }
  res.status(201).json({
    success: true,
    data: { url: `/uploads/${req.file.filename}`, filename: req.file.filename },
  });
});

export default router;
