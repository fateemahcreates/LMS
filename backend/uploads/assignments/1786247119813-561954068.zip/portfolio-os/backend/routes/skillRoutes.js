import express from "express";
import { getSkills, getSkill, createSkill, updateSkill, deleteSkill } from "../controllers/skillController.js";
import { protect, admin } from "../middleware/auth.js";

const router = express.Router();

router.get("/", getSkills);
router.get("/:id", getSkill);
router.post("/", protect, admin, createSkill);
router.put("/:id", protect, admin, updateSkill);
router.delete("/:id", protect, admin, deleteSkill);

export default router;
